
package mainpack;


import java.util.HashMap;
import java.util.Map;
import org.antlr.v4.runtime.Token;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adamd
 */
public class SymbolTable {
    Map<String, Type> dictionary = new HashMap<>();
    
    public void Add(Token variable, Type type){
        String name = variable.getText().trim();
        if(dictionary.containsKey(name))
        {
            Error.AppendError(variable, String.format("Variable %s was already declared.",name));
        }
        else
        {
            dictionary.put(name, type);
        }
    }
    public Type Get(Token variable){
        String name = variable.getText().trim();
        if(dictionary.containsKey(name))
        {
            return dictionary.get(name);
        }
        else
        {
            Error.AppendError(variable, String.format("Variable %s is not declared.",name));
            return Type.Error;
        }
    }
}
