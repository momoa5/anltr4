package mainpack;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeProperty;
import org.antlr.v4.runtime.tree.TerminalNode;

/**
 *
 * @author Uživatel
 */
public class TypeChecking extends ExprBaseListener {
    private SymbolTable symbolTable;
    
    public TypeChecking(SymbolTable st){
        this.symbolTable = st;
    }
    private ParseTreeProperty<Type> types = new ParseTreeProperty<>();
    public ParseTreeProperty<Type> GetParseTreeProperty(){
        return this.types;
    }
    private void SetNodeType(ParseTree node, Type value){
        types.put(node, value);
    }
    private Type GetNodeType(ParseTree node){
        return types.get(node);
    }
	@Override public void enterDeclaration(ExprParser.DeclarationContext ctx) { }
	@Override public void exitDeclaration(ExprParser.DeclarationContext ctx) { 
            Type type = GetNodeType(ctx.primitiveType());                              
            for( TerminalNode identifier : ctx.IDENTIFIER()){
                symbolTable.Add(identifier.getSymbol(), type); 
            };
        }
	@Override public void enterIf(ExprParser.IfContext ctx) { }
	@Override public void exitIf(ExprParser.IfContext ctx) { 
            Type type = GetNodeType(ctx.expression());
            if(type != Type.Bool){
                Error.AppendError(ctx.expression().start, "If argument was NOT evaluated as BOOL type.");
            }
        }
	@Override public void enterPrimitiveType(ExprParser.PrimitiveTypeContext ctx) { }
	@Override public void exitPrimitiveType(ExprParser.PrimitiveTypeContext ctx) { 
            String strType = ctx.getChild(0).getText();
            Type type;           
            switch (strType) {
            case "bool":
                type = Type.Bool; break;
            case "int":
                type = Type.Int;  break;
            case "float":
                type = Type.Float; break;
            case "string":
                type = Type.String; break;
            default:
                type = Type.Error; break;            
            }
            SetNodeType(ctx, type);
        }
	@Override public void enterAdd(ExprParser.AddContext ctx) { }
	@Override public void exitAdd(ExprParser.AddContext ctx) { 
            Type typeL = GetNodeType(ctx.expression(0));
            String oper = ctx.bop.getText();
            Type typeR = GetNodeType(ctx.expression(1));
            
            if(oper.equals(ExprParser.VOCABULARY.getLiteralName(ExprParser.DOT).replaceAll("'", ""))){
                if(typeL == Type.String && typeR == Type.String){
                    SetNodeType(ctx, Type.String);
                }
                else{
                    if(typeL != Type.Error && typeL != Type.String){
                        Error.AppendError(ctx.expression(0).start, "Concatenation operator can be used only with STRING type. "+typeL.toString()+" found instead on left side of expression.");
                    }
                    if(typeR != Type.Error && typeR != Type.String){
                        Error.AppendError(ctx.expression(1).start, "Concatenation operator can be used only with STRING type. "+typeR.toString()+" found instead on right side of expression.");
                    }
                    SetNodeType(ctx, Type.Error);
                }
            }
            else{
                if(typeL == Type.Int && typeR == Type.Int){
                    SetNodeType(ctx, Type.Int);
                }
                else if((typeL == Type.Int || typeL == Type.Float) && (typeR == Type.Int || typeR == Type.Float)){
                    SetNodeType(ctx, Type.Float);
                }
                else{
                    if(typeL != Type.Error && (typeL == Type.Int || typeL == Type.Float)){
                        Error.AppendError(ctx.expression(0).start, "Addition/substraction operator can be used only with INT or FLOAT types. "+typeL.toString()+" found instead on left side of expression.");
                    }
                    if(typeR != Type.Error && (typeR == Type.Int || typeR == Type.Float)){
                        Error.AppendError(ctx.expression(1).start, "Addition/substraction operator can be used only with INT or FLOAT types. "+typeR.toString()+" found instead on right side of expression.");
                    }
                    SetNodeType(ctx, Type.Error);
                }
            }
               
        }
	@Override public void enterAnd(ExprParser.AndContext ctx) { }
	@Override public void exitAnd(ExprParser.AndContext ctx) { 
            Type typeL = GetNodeType(ctx.expression(0));
            Type typeR = GetNodeType(ctx.expression(1));
            if(typeL == Type.Bool && typeR == Type.Bool){
                SetNodeType(ctx, Type.Bool);
            }
            else{
                if(typeL != Type.Error){
                    Error.AppendError(ctx.expression(0).start, "And can be used only with BOOL types. "+typeL.toString()+" found instead on left side of expression.");
                }
                if(typeR != Type.Error){
                    Error.AppendError(ctx.expression(1).start, "And can be used only with BOOL types. "+typeR.toString()+" found instead on right side of expression.");
                }
                SetNodeType(ctx, Type.Error);
            }
        }
	
	@Override public void enterNot(ExprParser.NotContext ctx) { }
	@Override public void exitNot(ExprParser.NotContext ctx) { 
            Type type = GetNodeType(ctx.expression());
            if(type == Type.Bool){
                SetNodeType(ctx, type);
            }
            else{
                if(type != Type.Error){
                    Error.AppendError(ctx.expression().start, "Not can be used only with BOOL type. "+type.toString()+" found instead.");
                }
                SetNodeType(ctx, Type.Error);
            }
        }
	
	@Override public void enterOr(ExprParser.OrContext ctx) { }
	@Override public void exitOr(ExprParser.OrContext ctx) { 
            Type typeL = GetNodeType(ctx.expression(0));
            Type typeR = GetNodeType(ctx.expression(1));
            if(typeL == Type.Bool && typeR == Type.Bool){
                SetNodeType(ctx, Type.Bool);
            }
            else{
                if(typeL != Type.Error){
                    Error.AppendError(ctx.expression(0).start, "Or can be used only with BOOL types. "+typeL.toString()+" found instead on left side of expression.");
                }
                if(typeR != Type.Error){
                    Error.AppendError(ctx.expression(1).start, "Or can be used only with BOOL types. "+typeR.toString()+" found instead on right side of expression.");
                }
                SetNodeType(ctx, Type.Error);
            }
        }
	
	@Override public void enterMul(ExprParser.MulContext ctx) { }
	@Override public void exitMul(ExprParser.MulContext ctx) { 
            Type typeL = GetNodeType(ctx.expression(0));
            String oper = ctx.bop.getText();
            Type typeR = GetNodeType(ctx.expression(1));
            if(oper.equals(ExprParser.VOCABULARY.getLiteralName(ExprParser.MOD).replaceAll("'", ""))){
                if(typeL == Type.Int && typeR == Type.Int){
                    SetNodeType(ctx, Type.Int);
                }
                else{
                    if(typeL != Type.Error && typeL != Type.Int){
                        Error.AppendError(ctx.expression(0).start, "Modulo operator can be used only with INT type. "+typeL.toString()+" found instead on left side of expression.");
                    }
                    if(typeR != Type.Error && typeR != Type.Int){
                        Error.AppendError(ctx.expression(1).start, "Modulo operator can be used only with INT type. "+typeR.toString()+" found instead on right side of expression.");
                    }
                    SetNodeType(ctx, Type.Error);
                }
            }
            else{
                if(typeL == Type.Int && typeR == Type.Int){
                    SetNodeType(ctx, Type.Int);
                }
                else if((typeL == Type.Int || typeL == Type.Float) && (typeR == Type.Int || typeR == Type.Float)){
                    SetNodeType(ctx, Type.Float);
                }
                else{
                    if(typeL != Type.Error && (typeL == Type.Int || typeL == Type.Float)){
                        Error.AppendError(ctx.expression(0).start, "Multiplication/division operator can be used only with INT or FLOAT types. "+typeL.toString()+" found instead on left side of expression.");
                    }
                    if(typeR != Type.Error && (typeR == Type.Int || typeR == Type.Float)){
                        Error.AppendError(ctx.expression(1).start, "Multiplication/division operator can be used only with INT or FLOAT types. "+typeR.toString()+" found instead on right side of expression.");
                    }
                    SetNodeType(ctx, Type.Error);
                }
            }
               
        }
	@Override public void enterAssignment(ExprParser.AssignmentContext ctx) { }
	@Override public void exitAssignment(ExprParser.AssignmentContext ctx) { 
            Type idenType = symbolTable.Get(ctx.IDENTIFIER().getSymbol());
            if(idenType == GetNodeType(ctx.expression())){
                SetNodeType(ctx, idenType);
            }
            
        }
	@Override public void enterUnaryMinus(ExprParser.UnaryMinusContext ctx) { }
	@Override public void exitUnaryMinus(ExprParser.UnaryMinusContext ctx) { 
            ExprParser.ExpressionContext con = ctx.expression();
            Type type = GetNodeType(ctx.expression());
            if(type == Type.Int || type == Type.Float){
                SetNodeType(ctx, type);
            }
            else{
                if(type != Type.Error){
                    Error.AppendError(ctx.expression().start, "Unary minus can be used only with INT or FLOAT type. "+type.toString()+" found instead.");
                }
                SetNodeType(ctx, Type.Error);
            }
        }
	
	@Override public void enterRelational(ExprParser.RelationalContext ctx) { }
	@Override public void exitRelational(ExprParser.RelationalContext ctx) { 
            Type typeL = GetNodeType(ctx.expression(0));
            Type typeR = GetNodeType(ctx.expression(1));
            if((typeL == Type.Int || typeL == Type.Float) && (typeR == Type.Int || typeR == Type.Float)){
                SetNodeType(ctx, Type.Bool);
            }
            else{
                if(typeL != Type.Error){
                    Error.AppendError(ctx.expression(0).start, "Relational operators can be used only with INT or FLOAT types. "+typeL.toString()+" found instead on left side of expression.");
                }
                if(typeR != Type.Error){
                    Error.AppendError(ctx.expression(1).start, "Relational operators can be used only with INT or FLOAT types. "+typeR.toString()+" found instead on right side of expression.");
                }
                SetNodeType(ctx, Type.Error);
            }
        }
	
	@Override public void enterValue(ExprParser.ValueContext ctx) { }
	@Override public void exitValue(ExprParser.ValueContext ctx) { 
            SetNodeType(ctx, GetNodeType(ctx.primary()));
        }
	
	@Override public void enterEquality(ExprParser.EqualityContext ctx) { }
	@Override public void exitEquality(ExprParser.EqualityContext ctx) { 
            Type typeL = GetNodeType(ctx.expression(0));
            Type typeR = GetNodeType(ctx.expression(1));
            if(((typeL == Type.Int || typeL == Type.Float) && (typeR == Type.Int || typeR == Type.Float)) || (typeL == Type.String && typeR == Type.String)){
                SetNodeType(ctx, Type.Bool);
            }
            else{
                if(typeL != Type.Error){
                    Error.AppendError(ctx.expression(0).start, "Equality operators can be used only with INT or FLOAT or String types. "+typeL.toString()+" found instead on left side of expression.");
                }
                if(typeR != Type.Error){
                    Error.AppendError(ctx.expression(1).start, "Equality operators can be used only with INT or FLOAT or String types. "+typeR.toString()+" found instead on right side of expression.");
                }
                SetNodeType(ctx, Type.Error);
            }
        }

	@Override public void enterPrimaryExpression(ExprParser.PrimaryExpressionContext ctx) { }
	@Override public void exitPrimaryExpression(ExprParser.PrimaryExpressionContext ctx) { 
            Type type = GetNodeType(ctx.expression());
            SetNodeType(ctx, type);
        }

   
        @Override public void enterPrimaryDecimal(ExprParser.PrimaryDecimalContext ctx) { }
	@Override public void exitPrimaryDecimal(ExprParser.PrimaryDecimalContext ctx) { 
            SetNodeType(ctx, Type.Int);
        }
	@Override public void enterPrimaryFloat(ExprParser.PrimaryFloatContext ctx) { }
	@Override public void exitPrimaryFloat(ExprParser.PrimaryFloatContext ctx) { 
            SetNodeType(ctx, Type.Float);
        }
	@Override public void enterPrimaryString(ExprParser.PrimaryStringContext ctx) { }
	@Override public void exitPrimaryString(ExprParser.PrimaryStringContext ctx) { 
            SetNodeType(ctx, Type.String);
        }
	@Override public void enterPrimaryBool(ExprParser.PrimaryBoolContext ctx) { }
	@Override public void exitPrimaryBool(ExprParser.PrimaryBoolContext ctx) { 
            SetNodeType(ctx, Type.Bool);
        }
	@Override public void enterPrimaryIdentifier(ExprParser.PrimaryIdentifierContext ctx) { }
	@Override public void exitPrimaryIdentifier(ExprParser.PrimaryIdentifierContext ctx) { 
            SetNodeType(ctx, symbolTable.Get(ctx.IDENTIFIER().getSymbol()));
        }
        
        
	@Override public void enterEveryRule(ParserRuleContext ctx) { }
	@Override public void exitEveryRule(ParserRuleContext ctx) { }
	@Override public void visitTerminal(TerminalNode node) { }
	@Override public void visitErrorNode(ErrorNode node) { }
}
