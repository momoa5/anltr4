/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainpack;

/**
 *
 * @author adamd
 */
public class ValueType {
    private Type type;
    private Object value;

    public ValueType(Type type, Object value) {
        this.type = type;
        this.value = value;
    }
    
    public String getDataTypeValue(){
        String value = "ERROR";
        switch(this.type)
        {
            case String:
                value = (String)this.value;
                break;
            case Int:
                 Integer iVal = (Integer)this.value;   
                value = iVal.toString();
                break;
            case Float:
                Float fVal = (Float)this.value;   
                value = fVal.toString();
                break;
            case Bool:
                Boolean bVal = (Boolean)this.value;   
                value = bVal.toString();
                break;
            default:
                break;

        }
       return value;
    }

    public Type getType() {
        return type;
    }

    public Object getValue() {
        return value;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public void setValue(Object value) {
        this.value = value;
    }
    
}
