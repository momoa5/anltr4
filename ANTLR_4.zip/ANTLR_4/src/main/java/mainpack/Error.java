package mainpack;


import java.util.ArrayList;
import java.util.List;
import org.antlr.v4.runtime.Token;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adamd
 */
public class Error {
    private static List<String> errors = new ArrayList<String>();
    
    static public void AppendError(Token token, String message)
    {
        errors.add(token.getLine()+":"+token.getCharPositionInLine()+" - "+message);
    }
    public static int getErrorCount()
    {
        return errors.size();
    }
    public static void PrintAndClearErrors()
    {
        for(String error : errors)
        {
            System.out.println(error);
        }
        errors.clear();
    }

    
}
