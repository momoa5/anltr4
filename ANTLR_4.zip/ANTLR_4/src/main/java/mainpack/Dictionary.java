/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainpack;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author adamd
 */
public class Dictionary {
    Map<String, ValueType> dictionary = new HashMap<>();
    
    public void Set(String variable, ValueType val){
        String name = variable;       
        dictionary.put(name, val);
        
    }
    public ValueType Get(String variable){
        String name = variable;
        if(dictionary.containsKey(name)){
            return dictionary.get(name);
        }
        else{
            return null;
        }
    }
}
