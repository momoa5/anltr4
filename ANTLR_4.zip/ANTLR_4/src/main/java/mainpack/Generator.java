package mainpack;


import java.util.Objects;
import mainpack.SymbolTable;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.tree.ParseTreeProperty;
import org.antlr.v4.runtime.tree.TerminalNode;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adamd
 */
public class Generator extends ExprBaseVisitor<String>{
    private SymbolTable symbolTable;
    private ParseTreeProperty<Type> types;
    private int label = -1;
    
    public Generator(SymbolTable symbolTableP, ParseTreeProperty<Type> typesP){
            symbolTable = symbolTableP;
            types = typesP;
        }
        
        private int nextLabel(){
            label++;
            return label;
        }
        private int previousLabel(){
            return label-1;
        }
        
        private char GetTypeAbbr(Type type){
            return type.toString().charAt(0);
        }
        
        @Override public String visitProgram(ExprParser.ProgramContext ctx) { 
            StringBuilder sb = new StringBuilder();
            for(ExprParser.StatementContext statement : ctx.statement()){
                String pt = visit(statement);
                if(!Objects.isNull(pt)) sb.append(pt); 
            }                      
            return sb.toString();
        }

	@Override public String visitBlock(ExprParser.BlockContext ctx) { 
            StringBuilder sb = new StringBuilder();
            for(ExprParser.StatementContext statement : ctx.statement()){
                String pt = visit(statement);
                if(!Objects.isNull(pt)) sb.append(pt);
            }                      
            return sb.toString();
        }
        
        @Override public String visitDeclaration(ExprParser.DeclarationContext ctx) { 
            StringBuilder sb = new StringBuilder(); 
            char typeS = visit(ctx.primitiveType()).toUpperCase().charAt(0);
            for(TerminalNode name : ctx.IDENTIFIER()){
                sb.append("push ").append(typeS);
                switch (typeS) {
                case 'B':
                    sb.append(" true"); break;
                case 'I':
                    sb.append(" 0");  break;
                case 'F':
                    sb.append(" 0.0"); break;
                case 'S':
                    sb.append(" \"\""); break;
                default:
                    sb.append(" ERROR"); break;            
                }
                sb.append('\n');
                
                sb.append("save ").append(name).append('\n');
            }
            return sb.toString();
        }

	@Override public String visitIf(ExprParser.IfContext ctx) { 
            StringBuilder sb = new StringBuilder(); 
            sb.append(visit(ctx.expression()));
            sb.append("fjmp ").append(nextLabel()).append('\n');
            sb.append(visit(ctx.statement(0)));
            sb.append("jmp ").append(nextLabel()).append('\n');
            sb.append("label ").append(previousLabel()).append('\n');
            if(ctx.statement(1) != null) sb.append(visit(ctx.statement(1)));
            sb.append("label ").append(label).append('\n');
            return sb.toString();
        }

	@Override public String visitWhile(ExprParser.WhileContext ctx) { 
            StringBuilder sb = new StringBuilder(); 
            sb.append("label ").append(nextLabel()).append('\n');
            sb.append(visit(ctx.expression()));           
            sb.append("fjmp ").append(nextLabel()).append('\n');
            sb.append(visit(ctx.statement()));
            sb.append("jmp ").append(previousLabel()).append('\n');
            sb.append("label ").append(label).append('\n');
            
            return sb.toString();
        }
	
	@Override public String visitStatementExpression(ExprParser.StatementExpressionContext ctx) { 
            return visit(ctx.expression()); 
        }
	
	@Override public String visitRead(ExprParser.ReadContext ctx) { 
            StringBuilder sb = new StringBuilder();
            for(TerminalNode iden : ctx.IDENTIFIER()){
                Token tk = iden.getSymbol();
                sb.append("read ").append(GetTypeAbbr(symbolTable.Get(tk))).append('\n');
                sb.append("save ").append(iden).append('\n');                
            }     

            return sb.toString();  
        }
	
	@Override public String visitWrite(ExprParser.WriteContext ctx) { 
            StringBuilder sb = new StringBuilder();
            for(ExprParser.ExpressionContext expr : ctx.expression()){
                String pt = visit(expr);
                if(!Objects.isNull(pt)) sb.append(pt);
            }     
            sb.append("print ").append(ctx.expression().size()).append('\n');

            return sb.toString(); 
        }
	
	@Override public String visitEmpty(ExprParser.EmptyContext ctx) { 
            return "";
        }
	
	@Override public String visitPrimitiveType(ExprParser.PrimitiveTypeContext ctx) { 
            return ctx.getChild(0).getText();
        }
	
	@Override public String visitAdd(ExprParser.AddContext ctx) { 
            StringBuilder sb = new StringBuilder(); 
            Type typeL = types.get(ctx.expression(0));
            Type typeR = types.get(ctx.expression(1));
            sb.append(visit(ctx.expression(0)));
            if(typeL == Type.Int && typeR == Type.Float) sb.append("itof\n");
            sb.append(visit(ctx.expression(1)));
            if(typeR == Type.Int && typeL == Type.Float) sb.append("itof\n");
            switch (ctx.bop.getText()) {
                case "+":
                    sb.append("add"); break;
                case "-":
                    sb.append("sub"); break;
                case ".":
                    sb.append("concat"); break;              
                default:
                    sb.append(" ERROR"); break;            
                }
                sb.append("\n");
            return sb.toString();  
        }
	
	@Override public String visitNot(ExprParser.NotContext ctx) { 
            StringBuilder sb = new StringBuilder(); 
            sb.append(visit(ctx.expression()));
            sb.append("not\n"); 
            return sb.toString();
        }
	
	@Override public String visitOr(ExprParser.OrContext ctx) { 
            StringBuilder sb = new StringBuilder(); 
            sb.append(visit(ctx.expression(0)));          
            sb.append(visit(ctx.expression(1)));
            sb.append("or");                
            sb.append("\n");
            return sb.toString();  
        }
	
	@Override public String visitMul(ExprParser.MulContext ctx) { 
            StringBuilder sb = new StringBuilder(); 
            Type typeL = types.get(ctx.expression(0));
            Type typeR = types.get(ctx.expression(1));
            sb.append(visit(ctx.expression(0)));
            if(typeL == Type.Int && typeR == Type.Float) sb.append("itof\n");
            sb.append(visit(ctx.expression(1)));
            if(typeR == Type.Int && typeL == Type.Float) sb.append("itof\n");
            switch (ctx.bop.getText()) {
                case "*":
                    sb.append("mul"); break;
                case "/":
                    sb.append("div"); break;
                case "%":
                    sb.append("mod"); break;              
                default:
                    sb.append(" ERROR"); break;            
                }
                sb.append("\n");
            return sb.toString(); 
        }
	
	@Override public String visitAssignment(ExprParser.AssignmentContext ctx) { 
            StringBuilder sb = new StringBuilder(); 
            sb.append(visit(ctx.expression()));
            if(symbolTable.Get(ctx.IDENTIFIER().getSymbol()) == Type.Float && types.get(ctx.expression()) == Type.Int) sb.append("itof\n");
            sb.append("save ").append(ctx.IDENTIFIER().getText()).append('\n');
            sb.append("load ").append(ctx.IDENTIFIER().getText()).append(" \n");
            if(ctx.parent.getClass() == ExprParser.StatementExpressionContext.class)
                sb.append("pop").append('\n');
            return sb.toString();
        }
	
	@Override public String visitAnd(ExprParser.AndContext ctx) { 
            StringBuilder sb = new StringBuilder(); 
            sb.append(visit(ctx.expression(0)));          
            sb.append(visit(ctx.expression(1)));
            sb.append("and");                
            sb.append("\n");
            return sb.toString(); 
        }
	
	@Override public String visitUnaryMinus(ExprParser.UnaryMinusContext ctx) { 
            StringBuilder sb = new StringBuilder(); 
            sb.append(visit(ctx.expression()));
            sb.append("uminus\n"); 
            return sb.toString();
        }
	
	@Override public String visitRelational(ExprParser.RelationalContext ctx) { 
            StringBuilder sb = new StringBuilder(); 
            Type typeL = types.get(ctx.expression(0));
            Type typeR = types.get(ctx.expression(1));
            sb.append(visit(ctx.expression(0)));
            if(typeL == Type.Int && typeR == Type.Float) sb.append("itof\n");
            sb.append(visit(ctx.expression(1)));
            if(typeR == Type.Int && typeL == Type.Float) sb.append("itof\n");
            switch (ctx.bop.getText()) {
                case "<":
                    sb.append("lt"); break;
                case ">":
                    sb.append("gt"); break;          
                default:
                    sb.append(" ERROR"); break;            
                }
                sb.append("\n");
            return sb.toString(); 
        }
	
	@Override public String visitValue(ExprParser.ValueContext ctx) { 
            return visit(ctx.primary()); 
        }
	
	@Override public String visitEquality(ExprParser.EqualityContext ctx) { 
            StringBuilder sb = new StringBuilder(); 
            Type typeL = types.get(ctx.expression(0));
            Type typeR = types.get(ctx.expression(1));
            sb.append(visit(ctx.expression(0)));
            if(typeL == Type.Int && typeR == Type.Float) sb.append("itof\n");
            sb.append(visit(ctx.expression(1)));
            if(typeR == Type.Int && typeL == Type.Float) sb.append("itof\n");
            switch (ctx.bop.getText()) {
                case "==":
                    sb.append("eq"); break;
                case "!=":
                    sb.append("eq");sb.append("\n");sb.append("not"); break;          
                default:
                    sb.append(" ERROR"); break;            
                }
                sb.append("\n");
            return sb.toString(); 
        }
	
	@Override public String visitPrimaryExpression(ExprParser.PrimaryExpressionContext ctx) { 
            return visit(ctx.expression()); 
        }
	
	@Override public String visitPrimaryDecimal(ExprParser.PrimaryDecimalContext ctx) { 
            StringBuilder sb = new StringBuilder();
            sb.append("push I ").append(ctx.DECIMAL_LITERAL().getText()).append('\n');
            return sb.toString();            
        }
	
	@Override public String visitPrimaryFloat(ExprParser.PrimaryFloatContext ctx) { 
            StringBuilder sb = new StringBuilder();
            sb.append("push F ").append(ctx.FLOAT_LITERAL().getText()).append('\n');
            return sb.toString();        
        }
	
	@Override public String visitPrimaryString(ExprParser.PrimaryStringContext ctx) { 
            StringBuilder sb = new StringBuilder();
            sb.append("push S ").append(ctx.STRING_LITERAL().getText()).append('\n');
            return sb.toString();        
        }
	
	@Override public String visitPrimaryBool(ExprParser.PrimaryBoolContext ctx) { 
            StringBuilder sb = new StringBuilder();
            sb.append("push B ").append(ctx.BOOL_LITERAL().getText()).append('\n');
            return sb.toString();         
        }
	
	@Override public String visitPrimaryIdentifier(ExprParser.PrimaryIdentifierContext ctx) { 
            StringBuilder sb = new StringBuilder();
            sb.append("load ").append(ctx.IDENTIFIER().getText()).append('\n');
            return sb.toString();
        }      
}
