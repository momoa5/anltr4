package mainpack;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import com.sun.org.apache.xpath.internal.axes.WalkerFactory;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import org.apache.commons.io.FilenameUtils;
/**
 *
 * @author Uživatel
 */

public class App {
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) throws IOException {
        ArrayList<String> fileNames = new ArrayList<>();
        fileNames.add("src/main/resources/PLC_t1.in");
        fileNames.add("src/main/resources/PLC_t2.in");
        fileNames.add("src/main/resources/PLC_t3.in");
      //  fileNames.add("src/main/resources/PLC_errors.in");
        
        for(String fileName : fileNames){
            File file = new File(fileName);
            InputStream targetStream;
            targetStream = new FileInputStream(file);

            System.out.println("\nAbsolute Path: " + file.getAbsolutePath());
            ExprLexer lexer = new ExprLexer(new ANTLRInputStream(targetStream));
            ExprParser parser = new ExprParser(new CommonTokenStream(lexer));
            parser.addErrorListener(new BaseErrorListener() {
                @Override
                public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int charPositionInLine, String msg, RecognitionException e) {
                    throw new IllegalStateException("failed to parse at line " + line + " due to " + msg, e);
                } 
            });        
            ParseTree tree = parser.program();
            if(parser.getNumberOfSyntaxErrors() == 0)
            {
                SymbolTable symbolTable = new SymbolTable();
                TypeChecking typeChecking = new TypeChecking(symbolTable);
                ParseTreeWalker walker = new ParseTreeWalker();
                walker.walk(typeChecking, tree);
                if(Error.getErrorCount()==0)
                {
                   System.out.println(tree.toStringTree(parser)); 
                   Generator gen= new Generator(symbolTable, typeChecking.GetParseTreeProperty());
                   String code = gen.visit(tree);
                   String newFilename = FilenameUtils.removeExtension(fileName)+".stc";
                   File fileOut = new File(newFilename);
                   fileOut.createNewFile();
                   FileOutputStream output = new FileOutputStream(newFilename);
                   byte[] strToBytes = code.getBytes();
                   output.write(strToBytes);
                   output.close();
                   //System.out.print(code);
                   EvaluateStackInstructions stackEvaluator = new EvaluateStackInstructions(fileOut.getPath());
                   stackEvaluator.evaluate();
                }
                else{
                    Error.PrintAndClearErrors();
                }
            }
            else System.out.print("There was a syntax error while parsing.");
        }
        
            
    }
    
}
