/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainpack;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Objects;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author adamd
 */
public class EvaluateStackInstructions {
    ArrayList<String> instructions = new ArrayList<>();
    Dictionary dictionary = new Dictionary();
    Deque<ValueType> stack = new ArrayDeque<ValueType>();
    int pointer = 0;
    
      public EvaluateStackInstructions(String instructionPath) {
        try (BufferedReader buffer = new BufferedReader(
                 new FileReader(instructionPath))) { 
            String str;
            while ((str = buffer.readLine()) != null) {
                instructions.add(str);
            }
        }
        catch (IOException ex) {
            Logger.getLogger(EvaluateStackInstructions.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
      public void evaluate(){
        while(pointer != instructions.size()){
            String[] sa = instructions.get(pointer).split(" ");
            
            /// POP INSTRUCTION
            if("pop".equals(sa[0])){
                stack.pop();
            }
            /// PUSH INSTRUCTION
            else if ("push".equals(sa[0])){
                switch(sa[1]){
                    case "I":
                        stack.push(new ValueType(Type.Int, Integer.parseInt(sa[2])));
                        break;
                    case "F":
                        stack.push(new ValueType(Type.Float, Float.parseFloat(sa[2])));
                        break;
                    case "S":
                        StringBuilder sb = new StringBuilder(); 
                        String ins = instructions.get(pointer);
                        sb.append(ins.substring(7));
                        stack.push(new ValueType(Type.String, stripQuotes(sb.toString())));
                        break;
                    case "B":
                        stack.push(new ValueType(Type.Bool, Boolean.parseBoolean(sa[2])));
                        break;                    
                }
            }
            /// READ INSTRUCTION
            else if ("read".equals(sa[0])){
                Scanner scan = new Scanner(System.in);
                switch(sa[1]){
                    case "I":
                        System.out.println("Awaiting Integer input: ");
                        stack.push(new ValueType(Type.Int, scan.nextInt()));
                        break;
                    case "F":
                        System.out.println("Awaiting Float input (0,0; not 0.0): ");
                        stack.push(new ValueType(Type.Float, scan.nextFloat()));
                        break;
                    case "S":
                        System.out.println("Awaiting String input: ");
                        stack.push(new ValueType(Type.String, scan.nextLine()));
                        break;
                    case "B":
                        System.out.println("Awaiting Boolean input (false/true): ");
                        stack.push(new ValueType(Type.Bool, scan.nextBoolean()));
                        break;                    
                }
            }
            /// WRITE INSTRUCTION
            else if ("print".equals(sa[0])){
                int numOfVals = Integer.parseInt(sa[1]);
                String s = ""; 
                for(int i = 0; i< numOfVals; i++){
                    s = stack.pop().getDataTypeValue() + s;
                }               
                System.out.println(s);
                               
            }
            /// UMINUS INSTRUCTION
            else if ("uminus".equals(sa[0])){
                ValueType tp = stack.pop();
                if(tp.getType()==Type.Int)
                {
                    Integer iVal = (Integer)tp.getValue();
                    stack.push(new ValueType(Type.Int, iVal*(-1)));
                }
                else if(tp.getType()==Type.Float)
                {
                    Float fVal = (Float)tp.getValue();
                    stack.push(new ValueType(Type.Float, fVal*(-1)));
                }
            }    
            /// NOT INSTRUCTION
            else if("not".equals(sa[0])){
                ValueType tp = stack.pop();
                if(tp.getType()==Type.Bool)
                {
                    Boolean bVal = (Boolean)tp.getValue();
                    stack.push(new ValueType(Type.Bool, !bVal));
                }
            }
            /// ITOF INSTRUCTION
            else if ("itof".equals(sa[0])){
                ValueType tp = stack.pop();
                if(tp.getType()==Type.Int){
                    Integer iVal = (Integer)tp.getValue();
                    Float fVal = iVal.floatValue();
                    stack.push(new ValueType(Type.Float, fVal));
                }
                //stack.push(new TypedValue)
            }
            /// VARIABLE SAVE
            else if ("save".equals(sa[0])){
                ValueType tp = stack.pop();
                dictionary.Set(sa[1], tp);
            }
            /// VARIABLE LOAD
            else if ("load".equals(sa[0])){
                stack.push(dictionary.Get(sa[1]));
            }
            
            /// JMP AND FJMP INSTRUCTION
            else if ("fjmp".equals(sa[0]) || "jmp".equals(sa[0])){
                Boolean fjmpB = true;
                if ("fjmp".equals(sa[0])){                    
                    ValueType tp = stack.pop();
                    if((Boolean)tp.getValue()) fjmpB = false;                    
                }
                if (fjmpB){
                    goToLabel(Integer.parseInt(sa[1]));
                }
            }
            /// BINARY OPERATIONS
            else if (sa[0].matches("add|sub|mul|div|mod|gt|lt|concat|and|or|eq")){
                ValueType right = stack.pop();
                ValueType left = stack.pop();
                if(right.getType()==Type.Int && left.getType()==Type.Int){
                    switch (sa[0]) {
                        case "add": stack.push(new ValueType(Type.Int, ((Integer)left.getValue() + (Integer)right.getValue()))); break;
                        case "sub": stack.push(new ValueType(Type.Int, ((Integer)left.getValue() - (Integer)right.getValue()))); break;
                        case "mul": stack.push(new ValueType(Type.Int, ((Integer)left.getValue() * (Integer)right.getValue()))); break;
                        case "div": stack.push(new ValueType(Type.Int, ((Integer)left.getValue() / (Integer)right.getValue()))); break;
                        case "mod": stack.push(new ValueType(Type.Int, ((Integer)left.getValue() % (Integer)right.getValue()))); break;
                        case "gt":  stack.push(new ValueType(Type.Bool, ((Integer)left.getValue() > (Integer)right.getValue()))); break;
                        case "lt":  stack.push(new ValueType(Type.Bool, ((Integer)left.getValue() < (Integer)right.getValue()))); break;
                        case "eq":  stack.push(new ValueType(Type.Bool, (Objects.equals((Integer)left.getValue(), (Integer)right.getValue())))); break;
                        default: break;
                    }
                }
                else if(right.getType()==Type.Float && left.getType()==Type.Float){
                    switch (sa[0]) {
                        case "add": stack.push(new ValueType(Type.Float, ((Float)left.getValue() + (Float)right.getValue()))); break;
                        case "sub": stack.push(new ValueType(Type.Float, ((Float)left.getValue() - (Float)right.getValue()))); break;
                        case "mul": stack.push(new ValueType(Type.Float, ((Float)left.getValue() * (Float)right.getValue()))); break;
                        case "div": stack.push(new ValueType(Type.Float, ((Float)left.getValue() / (Float)right.getValue()))); break;
                        case "gt":  stack.push(new ValueType(Type.Bool, ((Float)left.getValue() > (Float)right.getValue()))); break;
                        case "lt":  stack.push(new ValueType(Type.Bool, ((Float)left.getValue() < (Float)right.getValue()))); break;
                        case "eq":  stack.push(new ValueType(Type.Bool, (Objects.equals((Float)left.getValue(), (Float)right.getValue())))); break;
                        default: break;
                    }
                }
                else if(right.getType()==Type.String && left.getType()==Type.String){
                    switch (sa[0]) {                       
                        case "concat":  stack.push(new ValueType(Type.String, ((String)left.getValue() + (String)right.getValue()))); break;
                        case "eq":  stack.push(new ValueType(Type.Bool, (Objects.equals((String)left.getValue(), (String)right.getValue())))); break;
                        default: break;
                    }
                }
                else if(right.getType()==Type.Bool && left.getType()==Type.Bool){
                    switch (sa[0]) {                       
                        case "and":  stack.push(new ValueType(Type.Bool, ((Boolean)left.getValue() && (Boolean)right.getValue()))); break;
                        case "or":  stack.push(new ValueType(Type.Bool, ((Boolean)left.getValue() || (Boolean)right.getValue()))); break;
                        case "eq":  stack.push(new ValueType(Type.Bool, (Objects.equals((String)left.getValue(), (String)right.getValue())))); break;
                        default: break;
                    }
                }
                
            }
            
            pointer += 1;
             
        }
        
    }
    private void goToLabel(int label){
        for(int i = 0; i< instructions.size(); i++){
            if((instructions.get(i)).matches("label "+label)){
                pointer = i;
                return;
            }
                
        }
    }
    private String stripQuotes(String string){
        return string.replaceAll("^\"|\"$", "");
    }
}
